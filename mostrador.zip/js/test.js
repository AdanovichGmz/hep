﻿
function SelecLinea() { 
    nommaquina.textfield.value=nommaquina.select.options[nommaquina.select.selectedIndex].text; 
} 
