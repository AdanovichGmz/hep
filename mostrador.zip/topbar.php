
<div class="topnav" id="myTopnav">
<a href="#" class="navlogo"></a>
  <a id="sales" href="../ventas/">Mostrador</a>
  <a id="moves" href="movimientos.php">Movimientos</a>
  <a id="info" href="info.php">Info</a>
  <a id="products" href="productos.php">Productos</a>
  <a id="invitations" href="invitaciones.php">Invitaciones</a>
  <a id="files" href="files.php">Archivos</a>
  <a id="billing" href="facturas.php">Facturas</a>
  <a  href="../logout.php" class="exit">Salir</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>





